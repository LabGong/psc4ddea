Background concepts
===================

.. toctree::
   :maxdepth: 2

   Evo_algo
   interactive_opt
   surrogate_modelling