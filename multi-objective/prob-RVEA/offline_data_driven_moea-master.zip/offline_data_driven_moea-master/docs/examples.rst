Examples
========

.. toctree::
   :maxdepth: 2
   :caption: Available examples:

   notebooks/Example
   notebooks/River_Pollution