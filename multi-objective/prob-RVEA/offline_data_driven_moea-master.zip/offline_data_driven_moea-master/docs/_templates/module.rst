{{ fullname }}
{{ underline }}

.. automodule:: {{ fullname }}