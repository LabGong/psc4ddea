EvoDN2
======

.. currentmodule:: desdeo_emo.surrogatemodelling

.. autoclass:: EvoDN2
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~EvoDN2.activate
      ~EvoDN2.fit
      ~EvoDN2.predict
      ~EvoDN2.select

   .. rubric:: Methods Documentation

   .. automethod:: activate
   .. automethod:: fit
   .. automethod:: predict
   .. automethod:: select
