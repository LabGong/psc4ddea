BaseEA
======

.. currentmodule:: desdeo_emo.EAs

.. autoclass:: BaseEA
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BaseEA.check_FE_count
      ~BaseEA.continue_evolution
      ~BaseEA.continue_iteration
      ~BaseEA.iterate
      ~BaseEA.manage_preferences
      ~BaseEA.requests

   .. rubric:: Methods Documentation

   .. automethod:: check_FE_count
   .. automethod:: continue_evolution
   .. automethod:: continue_iteration
   .. automethod:: iterate
   .. automethod:: manage_preferences
   .. automethod:: requests
