PPGA
====

.. currentmodule:: desdeo_emo.EAs

.. autoclass:: PPGA
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~PPGA.manage_preferences
      ~PPGA.select

   .. rubric:: Methods Documentation

   .. automethod:: manage_preferences
   .. automethod:: select
