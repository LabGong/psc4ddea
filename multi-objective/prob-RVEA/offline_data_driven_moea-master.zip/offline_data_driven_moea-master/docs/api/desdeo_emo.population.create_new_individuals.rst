create_new_individuals
======================

.. currentmodule:: desdeo_emo.population

.. autofunction:: create_new_individuals
