TournamentEA
============

.. currentmodule:: desdeo_emo.EAs

.. autoclass:: TournamentEA
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~TournamentEA.select

   .. rubric:: Methods Documentation

   .. automethod:: select
