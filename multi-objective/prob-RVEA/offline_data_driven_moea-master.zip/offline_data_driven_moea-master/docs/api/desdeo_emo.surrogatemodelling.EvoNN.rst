EvoNN
=====

.. currentmodule:: desdeo_emo.surrogatemodelling

.. autoclass:: EvoNN
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~EvoNN.activate
      ~EvoNN.calculate_linear
      ~EvoNN.fit
      ~EvoNN.predict
      ~EvoNN.select

   .. rubric:: Methods Documentation

   .. automethod:: activate
   .. automethod:: calculate_linear
   .. automethod:: fit
   .. automethod:: predict
   .. automethod:: select
