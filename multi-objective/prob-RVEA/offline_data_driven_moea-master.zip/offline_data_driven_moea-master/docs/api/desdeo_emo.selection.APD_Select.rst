APD_Select
==========

.. currentmodule:: desdeo_emo.selection

.. autoclass:: APD_Select
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~APD_Select.do

   .. rubric:: Methods Documentation

   .. automethod:: do
