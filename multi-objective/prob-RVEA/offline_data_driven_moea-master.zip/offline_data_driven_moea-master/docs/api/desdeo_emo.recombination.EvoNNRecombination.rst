EvoNNRecombination
==================

.. currentmodule:: desdeo_emo.recombination

.. autoclass:: EvoNNRecombination
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~EvoNNRecombination.do

   .. rubric:: Methods Documentation

   .. automethod:: do
