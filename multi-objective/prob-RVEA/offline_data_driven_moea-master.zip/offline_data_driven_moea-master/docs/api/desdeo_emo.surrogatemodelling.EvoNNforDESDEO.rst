EvoNNforDESDEO
==============

.. currentmodule:: desdeo_emo.surrogatemodelling

.. autoclass:: EvoNNforDESDEO
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~EvoNNforDESDEO.predict

   .. rubric:: Methods Documentation

   .. automethod:: predict
