BioGP_mutation
==============

.. currentmodule:: desdeo_emo.recombination

.. autoclass:: BioGP_mutation
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BioGP_mutation.do

   .. rubric:: Methods Documentation

   .. automethod:: do
