desdeo\_emo.othertools package
==============================

Submodules
----------

desdeo\_emo.othertools.IsNotebook module
----------------------------------------

.. automodule:: desdeo_emo.othertools.IsNotebook
   :members:
   :undoc-members:
   :show-inheritance:

desdeo\_emo.othertools.ReferenceVectors module
----------------------------------------------

.. automodule:: desdeo_emo.othertools.ReferenceVectors
   :members:
   :undoc-members:
   :show-inheritance:

desdeo\_emo.othertools.newRV module
-----------------------------------

.. automodule:: desdeo_emo.othertools.newRV
   :members:
   :undoc-members:
   :show-inheritance:

desdeo\_emo.othertools.plotlyanimate module
-------------------------------------------

.. automodule:: desdeo_emo.othertools.plotlyanimate
   :members:
   :undoc-members:
   :show-inheritance:

desdeo\_emo.othertools.symmetric\_vectors module
------------------------------------------------

.. automodule:: desdeo_emo.othertools.symmetric_vectors
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: desdeo_emo.othertools
   :members:
   :undoc-members:
   :show-inheritance:
