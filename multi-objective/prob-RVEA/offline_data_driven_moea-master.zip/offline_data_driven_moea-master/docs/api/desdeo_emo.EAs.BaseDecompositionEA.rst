BaseDecompositionEA
===================

.. currentmodule:: desdeo_emo.EAs

.. autoclass:: BaseDecompositionEA
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BaseDecompositionEA.manage_preferences
      ~BaseDecompositionEA.request_plot
      ~BaseDecompositionEA.request_preferences
      ~BaseDecompositionEA.requests

   .. rubric:: Methods Documentation

   .. automethod:: manage_preferences
   .. automethod:: request_plot
   .. automethod:: request_preferences
   .. automethod:: requests
