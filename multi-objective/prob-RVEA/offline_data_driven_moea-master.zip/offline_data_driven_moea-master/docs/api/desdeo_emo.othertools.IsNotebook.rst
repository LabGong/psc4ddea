IsNotebook
==========

.. currentmodule:: desdeo_emo.othertools

.. autofunction:: IsNotebook
