tour_select
===========

.. currentmodule:: desdeo_emo.selection

.. autofunction:: tour_select
