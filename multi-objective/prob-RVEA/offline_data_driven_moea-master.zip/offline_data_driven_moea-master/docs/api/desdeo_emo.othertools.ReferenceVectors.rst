ReferenceVectors
================

.. currentmodule:: desdeo_emo.othertools

.. autoclass:: ReferenceVectors
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~ReferenceVectors.adapt
      ~ReferenceVectors.add_edge_vectors
      ~ReferenceVectors.iteractive_adapt_1
      ~ReferenceVectors.neighbouring_angles
      ~ReferenceVectors.normalize
      ~ReferenceVectors.slow_interactive_adapt

   .. rubric:: Methods Documentation

   .. automethod:: adapt
   .. automethod:: add_edge_vectors
   .. automethod:: iteractive_adapt_1
   .. automethod:: neighbouring_angles
   .. automethod:: normalize
   .. automethod:: slow_interactive_adapt
