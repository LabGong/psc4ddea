desdeo_emo
==========

.. toctree::
   :maxdepth: 4

   desdeo_emo
