animate_init_
=============

.. currentmodule:: desdeo_emo.othertools

.. autofunction:: animate_init_
