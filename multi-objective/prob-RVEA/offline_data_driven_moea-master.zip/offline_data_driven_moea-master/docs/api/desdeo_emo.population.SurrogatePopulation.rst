SurrogatePopulation
===================

.. currentmodule:: desdeo_emo.population

.. autoclass:: SurrogatePopulation
   :show-inheritance:
