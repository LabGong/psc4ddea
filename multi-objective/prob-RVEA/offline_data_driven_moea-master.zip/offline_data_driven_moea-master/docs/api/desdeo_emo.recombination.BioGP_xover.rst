BioGP_xover
===========

.. currentmodule:: desdeo_emo.recombination

.. autoclass:: BioGP_xover
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BioGP_xover.do

   .. rubric:: Methods Documentation

   .. automethod:: do
