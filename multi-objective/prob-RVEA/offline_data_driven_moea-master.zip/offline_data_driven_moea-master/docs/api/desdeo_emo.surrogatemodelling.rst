desdeo\_emo.surrogatemodelling package
======================================

Submodules
----------

desdeo\_emo.surrogatemodelling.BioGP module
-------------------------------------------

.. automodule:: desdeo_emo.surrogatemodelling.BioGP
   :members:
   :undoc-members:
   :show-inheritance:

desdeo\_emo.surrogatemodelling.EvoDN2 module
--------------------------------------------

.. automodule:: desdeo_emo.surrogatemodelling.EvoDN2
   :members:
   :undoc-members:
   :show-inheritance:

desdeo\_emo.surrogatemodelling.EvoNN module
-------------------------------------------

.. automodule:: desdeo_emo.surrogatemodelling.EvoNN
   :members:
   :undoc-members:
   :show-inheritance:

desdeo\_emo.surrogatemodelling.Problem module
---------------------------------------------

.. automodule:: desdeo_emo.surrogatemodelling.Problem
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: desdeo_emo.surrogatemodelling
   :members:
   :undoc-members:
   :show-inheritance:
