RVEA
====

.. currentmodule:: desdeo_emo.EAs

.. autoclass:: RVEA
   :show-inheritance:
