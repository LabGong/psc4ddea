NSGAIII_select
==============

.. currentmodule:: desdeo_emo.selection

.. autoclass:: NSGAIII_select
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~NSGAIII_select.associate_to_niches
      ~NSGAIII_select.calc_niche_count
      ~NSGAIII_select.calc_perpendicular_distance
      ~NSGAIII_select.do
      ~NSGAIII_select.get_extreme_points_c
      ~NSGAIII_select.get_nadir_point
      ~NSGAIII_select.niching

   .. rubric:: Methods Documentation

   .. automethod:: associate_to_niches
   .. automethod:: calc_niche_count
   .. automethod:: calc_perpendicular_distance
   .. automethod:: do
   .. automethod:: get_extreme_points_c
   .. automethod:: get_nadir_point
   .. automethod:: niching
