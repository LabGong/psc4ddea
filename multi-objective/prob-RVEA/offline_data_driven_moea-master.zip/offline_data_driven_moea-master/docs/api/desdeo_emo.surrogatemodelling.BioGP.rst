BioGP
=====

.. currentmodule:: desdeo_emo.surrogatemodelling

.. autoclass:: BioGP
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BioGP.add
      ~BioGP.cos
      ~BioGP.div
      ~BioGP.fit
      ~BioGP.log
      ~BioGP.mul
      ~BioGP.neg
      ~BioGP.predict
      ~BioGP.select
      ~BioGP.sin
      ~BioGP.sqrt
      ~BioGP.sub
      ~BioGP.tan

   .. rubric:: Methods Documentation

   .. automethod:: add
   .. automethod:: cos
   .. automethod:: div
   .. automethod:: fit
   .. automethod:: log
   .. automethod:: mul
   .. automethod:: neg
   .. automethod:: predict
   .. automethod:: select
   .. automethod:: sin
   .. automethod:: sqrt
   .. automethod:: sub
   .. automethod:: tan
