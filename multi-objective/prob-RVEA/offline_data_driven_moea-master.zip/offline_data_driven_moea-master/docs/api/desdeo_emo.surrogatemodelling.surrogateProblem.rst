surrogateProblem
================

.. currentmodule:: desdeo_emo.surrogatemodelling

.. autoclass:: surrogateProblem
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~surrogateProblem.evaluate
      ~surrogateProblem.evaluate_constraint_values
      ~surrogateProblem.get_objective_names
      ~surrogateProblem.get_variable_bounds

   .. rubric:: Methods Documentation

   .. automethod:: evaluate
   .. automethod:: evaluate_constraint_values
   .. automethod:: get_objective_names
   .. automethod:: get_variable_bounds
