EvoDN2Recombination
===================

.. currentmodule:: desdeo_emo.recombination

.. autoclass:: EvoDN2Recombination
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~EvoDN2Recombination.do

   .. rubric:: Methods Documentation

   .. automethod:: do
