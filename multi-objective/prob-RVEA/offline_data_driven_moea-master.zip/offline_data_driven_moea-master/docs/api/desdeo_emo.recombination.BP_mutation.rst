BP_mutation
===========

.. currentmodule:: desdeo_emo.recombination

.. autoclass:: BP_mutation
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BP_mutation.do

   .. rubric:: Methods Documentation

   .. automethod:: do
