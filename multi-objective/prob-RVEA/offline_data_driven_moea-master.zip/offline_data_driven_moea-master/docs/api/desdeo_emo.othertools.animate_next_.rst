animate_next_
=============

.. currentmodule:: desdeo_emo.othertools

.. autofunction:: animate_next_
