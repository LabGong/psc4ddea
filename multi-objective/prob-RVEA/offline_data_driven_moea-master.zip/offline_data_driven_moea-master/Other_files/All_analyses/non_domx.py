from pygmo import fast_non_dominated_sorting as nds


def ndx(data):
    return nds(data)
