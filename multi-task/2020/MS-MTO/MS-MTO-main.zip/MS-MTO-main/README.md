# MS-MTO
Liao P, Sun C, Zhang G, et al. Multi-surrogate multi-tasking optimization of expensive problems[J]. Knowledge-Based Systems, 2020, 205: 106262.
# 10-3
