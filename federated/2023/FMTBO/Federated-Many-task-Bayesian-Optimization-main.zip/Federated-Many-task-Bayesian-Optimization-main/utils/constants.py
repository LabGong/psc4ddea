Benchmarks = ['Ackley', 'Griewank', 'Ellipsoid', 'Rastrigin', 'Rosenbrock']
Acquisitions = ['EI', 'EI_w']

Opts = ['sgd', 'm-sgd', 'max-gd']
