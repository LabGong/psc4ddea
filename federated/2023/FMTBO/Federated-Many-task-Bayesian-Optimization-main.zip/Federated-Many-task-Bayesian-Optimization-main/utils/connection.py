
def online(clients):
    """We assume all users are always online."""
    return clients
