class BenchmarkBase:
    def __init__(self):
        self.functions = []
        self.space = []
        self.opt_x = []
        self.opt_y = []
